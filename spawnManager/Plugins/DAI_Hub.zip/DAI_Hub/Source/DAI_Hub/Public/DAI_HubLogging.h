#pragma once
#include "CoreMinimal.h"

DAI_HUB_API DECLARE_LOG_CATEGORY_EXTERN(LogDAIHub, Log, All);
DAI_HUB_API DECLARE_LOG_CATEGORY_EXTERN(LogTemplateCharacter, Log, All);
// add more shared categories here if you want
