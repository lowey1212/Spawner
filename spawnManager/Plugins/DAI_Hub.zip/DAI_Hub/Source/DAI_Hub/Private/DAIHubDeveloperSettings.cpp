#include "DAIHubDeveloperSettings.h"

UDAIHubDeveloperSettings::UDAIHubDeveloperSettings()
    : bDebug(false)
{
}
