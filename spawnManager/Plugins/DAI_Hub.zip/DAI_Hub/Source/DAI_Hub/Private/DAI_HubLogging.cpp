#include "DAI_HubLogging.h"

DEFINE_LOG_CATEGORY(LogTemplateCharacter);
