# DAI_Hub / AIFactionService

_Declared in `Source/DAI_Hub/Public/Interfaces/DAIFactionService.h`._
