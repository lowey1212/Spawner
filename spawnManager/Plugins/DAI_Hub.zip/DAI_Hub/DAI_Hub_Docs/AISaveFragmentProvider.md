# DAI_Hub / AISaveFragmentProvider

_Declared in `Source/DAI_Hub/Public/Interfaces/DAISaveFragmentProvider.h`._
