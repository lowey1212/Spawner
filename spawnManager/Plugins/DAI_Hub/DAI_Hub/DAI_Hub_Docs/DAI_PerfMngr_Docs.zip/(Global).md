# DAI_PerfMngr / (Global)

_Declared in `Source/DAI_PerfMngr/Public/DAI_PerfMngrComponent.h`._


## Exposed Settings

| Setting | Type | Where | Notes |
|---|---|---|---|
| **DAI_ComponentType** (`ComponentType`) | `ESuppressionComponentType` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_ComponentTagFilter** (`ComponentTagFilter`) | `FName` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_NameContains** (`NameContains`) | `FString` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_SuppressionThreshold** (`SuppressionThreshold`) | `float` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_ComponentTickInterval** (`ComponentTickInterval`) | `float` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_EditCondition** (`EditCondition`) | `` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_ComponentTickIntervalLow** (`ComponentTickIntervalLow`) | `float` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_bPrintTickRate** (`bPrintTickRate`) | `bool` | `DAI|Perf` | BlueprintReadWrite |


### Setting Details

#### DAI_bPrintTickRate (`bPrintTickRate`)

> About this setting: b Print Tick Rate.

- **Type:** `bool`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_ComponentTagFilter (`ComponentTagFilter`)

> About this setting: Component Tag Filter.

- **Type:** `FName`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_ComponentTickInterval (`ComponentTickInterval`)

> Tick interval to apply while suppressed (0 disables the component

- **Type:** `float`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_ComponentTickIntervalLow (`ComponentTickIntervalLow`)

> Tick interval when component is barely significant but above suppression threshold.

- **Type:** `float`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_ComponentType (`ComponentType`)

> About this setting: Component Type.

- **Type:** `ESuppressionComponentType`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_EditCondition (`EditCondition`)

> Tick interval when component is highly significant (active

- **Type:** ``

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_NameContains (`NameContains`)

> About this setting: Name Contains.

- **Type:** `FString`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_SuppressionThreshold (`SuppressionThreshold`)

> Significance value below which the component will be disabled.

- **Type:** `float`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite

