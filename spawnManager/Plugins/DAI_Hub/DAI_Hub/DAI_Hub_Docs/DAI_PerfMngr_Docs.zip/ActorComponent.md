# DAI_PerfMngr / ActorComponent

_Declared in `Source/DAI_PerfMngr/Public/DAI_PerfMngrComponent.h`._

## Blueprint Nodes

### DAI_ForceSwapToFull

> What this does: unknown.

- **Blueprint Category:** `DAI|Perf`

- **Node Type:** `BlueprintCallable`

**Signature**

`void Unknown()`

**Inputs**

_No inputs._

**Returns**: `void`

### DAI_ForceSwapToProxy

> What this does: unknown.

- **Blueprint Category:** `DAI|Perf`

- **Node Type:** `BlueprintCallable`

**Signature**

`void Unknown()`

**Inputs**

_No inputs._

**Returns**: `void`

### DAI_GetCurrentProxyState

> What this does: unknown.

- **Blueprint Category:** `DAI|Perf`

- **Node Type:** `BlueprintCallable`

**Signature**

`void Unknown()`

**Inputs**

_No inputs._

**Returns**: `void`

### DAI_IsUsingProxy

> What this does: unknown.

- **Blueprint Category:** `DAI|Perf`

- **Node Type:** `BlueprintCallable`

**Signature**

`void Unknown()`

**Inputs**

_No inputs._

**Returns**: `void`

### DAI_SetPerformanceQuality

> What this does: unknown.

- **Blueprint Category:** `DAI|Perf`

- **Node Type:** `BlueprintCallable`

**Signature**

`void Unknown()`

**Inputs**

_No inputs._

**Returns**: `void`

### DAI_SwapToFull

> What this does: unknown.

- **Blueprint Category:** `DAI|Perf`

- **Node Type:** `BlueprintCallable`

**Signature**

`void Unknown()`

**Inputs**

_No inputs._

**Returns**: `void`

### DAI_SwapToProxy

> What this does: unknown.

- **Blueprint Category:** `DAI|Perf`

- **Node Type:** `BlueprintCallable`

**Signature**

`void Unknown()`

**Inputs**

_No inputs._

**Returns**: `void`


## Exposed Settings

| Setting | Type | Where | Notes |
|---|---|---|---|
| **DAI_MaxDistance** (`MaxDistance`) | `float` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_TickEvaluationRate** (`TickEvaluationRate`) | `float` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_TickIntervalHigh** (`TickIntervalHigh`) | `float` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_TickIntervalLow** (`TickIntervalLow`) | `float` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_PerformanceQuality** (`PerformanceQuality`) | `EPerformanceQuality` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_MinTickClamp** (`MinTickClamp`) | `float` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_MaxTickClamp** (`MaxTickClamp`) | `float` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_bAffectAbilitySystemTick** (`bAffectAbilitySystemTick`) | `bool` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_bEnableDebugLog** (`bEnableDebugLog`) | `bool` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_bPrintSignificanceToScreen** (`bPrintSignificanceToScreen`) | `bool` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_bDrawDebugProxySphere** (`bDrawDebugProxySphere`) | `bool` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_ProxyDebugSphereDuration** (`ProxyDebugSphereDuration`) | `float` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_mode** (`UStaticMesh`) | `` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_Category** (`UStaticMesh`) | `` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_Category** (`UStaticMesh`) | `` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_Category** (`UNiagaraSystem`) | `` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_Category** (`UNiagaraSystem`) | `class` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_Category** (`UMaterialInterface`) | `class` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_BillboardFadeDuration** (`BillboardFadeDuration`) | `float` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_BillboardProxyTag** (`BillboardProxyTag`) | `FName` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_BillboardEnterThreshold** (`BillboardEnterThreshold`) | `float` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_BillboardExitThreshold** (`BillboardExitThreshold`) | `float` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_ParticleProxyTag** (`ParticleProxyTag`) | `FName` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_ParticleEnterThreshold** (`ParticleEnterThreshold`) | `float` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_ParticleExitThreshold** (`ParticleExitThreshold`) | `float` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_HairProxyTag** (`HairProxyTag`) | `FName` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_Category** (`Category`) | `FName` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_bColorizeBySignificance** (`bColorizeBySignificance`) | `bool` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_ComponentSuppressionRules** (`ComponentSuppressionRules`) | `TArray<FComponentSuppressionRule>` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_ProxyEnterThreshold** (`ProxyEnterThreshold`) | `float` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_ProxyExitThreshold** (`ProxyExitThreshold`) | `float` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_ProxySwapDelay** (`ProxySwapDelay`) | `float` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_meta** (`int32`) | `` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_bAllowAIThrottling** (`bAllowAIThrottling`) | `bool` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_AIDeepFreezeSignificance** (`AIDeepFreezeSignificance`) | `float` | `DAI|Perf` | BlueprintReadWrite |
| **DAI_OnProxyEntered** (`OnProxyEntered`) | `FOnProxyEnteredSignature` | `DAI|Perf` | BlueprintAssignable |
| **DAI_OnProxyExited** (`OnProxyExited`) | `FOnProxyExitedSignature` | `DAI|Perf` | BlueprintAssignable |


### Setting Details

#### DAI_AIDeepFreezeSignificance (`AIDeepFreezeSignificance`)

> When significance is below this

- **Type:** `float`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_bAffectAbilitySystemTick (`bAffectAbilitySystemTick`)

> About this setting: b Affect Ability System Tick.

- **Type:** `bool`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_bAllowAIThrottling (`bAllowAIThrottling`)

> About this setting: b Allow AIThrottling.

- **Type:** `bool`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_bColorizeBySignificance (`bColorizeBySignificance`)

> About this setting: b Colorize By Significance.

- **Type:** `bool`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_bDrawDebugProxySphere (`bDrawDebugProxySphere`)

> About this setting: b Draw Debug Proxy Sphere.

- **Type:** `bool`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_bEnableDebugLog (`bEnableDebugLog`)

> About this setting: b Enable Debug Log.

- **Type:** `bool`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_BillboardEnterThreshold (`BillboardEnterThreshold`)

> When significance is below this

- **Type:** `float`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_BillboardExitThreshold (`BillboardExitThreshold`)

> When significance rises above this

- **Type:** `float`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_BillboardFadeDuration (`BillboardFadeDuration`)

> How long to cross-fade (in seconds

- **Type:** `float`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_BillboardProxyTag (`BillboardProxyTag`)

> About this setting: Billboard Proxy Tag.

- **Type:** `FName`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_bPrintSignificanceToScreen (`bPrintSignificanceToScreen`)

> About this setting: b Print Significance To Screen.

- **Type:** `bool`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_Category (`UStaticMesh`)

> About this setting: UStatic Mesh.

- **Type:** ``

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_Category (`UStaticMesh`)

> About this setting: UStatic Mesh.

- **Type:** ``

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_Category (`UNiagaraSystem`)

> About this setting: UNiagara System.

- **Type:** ``

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_Category (`UNiagaraSystem`)

> About this setting: UNiagara System.

- **Type:** `class`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_Category (`UMaterialInterface`)

> About this setting: UMaterial Interface.

- **Type:** `class`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_Category (`Category`)

> About this setting: Category.

- **Type:** `FName`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_ComponentSuppressionRules (`ComponentSuppressionRules`)

> About this setting: Component Suppression Rules.

- **Type:** `TArray<FComponentSuppressionRule>`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_HairProxyTag (`HairProxyTag`)

> About this setting: Hair Proxy Tag.

- **Type:** `FName`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_MaxDistance (`MaxDistance`)

> How far from the player this actor can be before we prefer cheaper representations (proxies/billboards

- **Type:** `float`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_MaxTickClamp (`MaxTickClamp`)

> Maximum allowed tick interval after clamping.

- **Type:** `float`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_meta (`int32`)

> Number of proxy instances to add to each HISM per tick (throttles mass adds

- **Type:** ``

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_MinTickClamp (`MinTickClamp`)

> Minimum allowed tick interval after clamping.

- **Type:** `float`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_mode (`UStaticMesh`)

> About this setting: UStatic Mesh.

- **Type:** ``

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_OnProxyEntered (`OnProxyEntered`)

> About this setting: On Proxy Entered.

- **Type:** `FOnProxyEnteredSignature`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintAssignable


#### DAI_OnProxyExited (`OnProxyExited`)

> About this setting: On Proxy Exited.

- **Type:** `FOnProxyExitedSignature`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintAssignable


#### DAI_ParticleEnterThreshold (`ParticleEnterThreshold`)

> When significance is below this

- **Type:** `float`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_ParticleExitThreshold (`ParticleExitThreshold`)

> When significance rises above this

- **Type:** `float`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_ParticleProxyTag (`ParticleProxyTag`)

> About this setting: Particle Proxy Tag.

- **Type:** `FName`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_PerformanceQuality (`PerformanceQuality`)

> About this setting: Performance Quality.

- **Type:** `EPerformanceQuality`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_ProxyDebugSphereDuration (`ProxyDebugSphereDuration`)

> How long (seconds

- **Type:** `float`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_ProxyEnterThreshold (`ProxyEnterThreshold`)

> When significance is below this

- **Type:** `float`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_ProxyExitThreshold (`ProxyExitThreshold`)

> When significance rises above this

- **Type:** `float`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_ProxySwapDelay (`ProxySwapDelay`)

> Grace period before a swap actually happens. Helps avoid flicker when value bounces around.

- **Type:** `float`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_TickEvaluationRate (`TickEvaluationRate`)

> How often (in seconds

- **Type:** `float`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_TickIntervalHigh (`TickIntervalHigh`)

> Tick interval to use when the actor is close or important (smaller = more updates

- **Type:** `float`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite


#### DAI_TickIntervalLow (`TickIntervalLow`)

> Tick interval to use when the actor is far or unimportant (larger = fewer updates

- **Type:** `float`

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite

