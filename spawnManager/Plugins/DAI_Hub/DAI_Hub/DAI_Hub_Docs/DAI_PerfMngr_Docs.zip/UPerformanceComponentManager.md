# DAI_PerfMngr / UPerformanceComponentManager

_Declared in `Source/DAI_PerfMngr/Public/PerformanceComponentManager.h`._

## Blueprint Nodes

### DAI_SetComponentActive

> Set Component Active.

- **Blueprint Category:** `DAI|Perf`

- **Node Type:** `BlueprintCallable`

**Signature**

`void SetComponentActive(AActor* Target, EManagedComponentType Type, bool bActive)`

**Inputs**

| Name | Type | Default |
|---|---|---|
| `Target` | `AActor*` | `` |
| `Type` | `EManagedComponentType` | `` |
| `bActive` | `bool` | `` |

**Returns**: `void`
