# DAI_PerfMngr / Actor

_Declared in `Source/DAI_PerfMngr/Public/ProxyHISMRootActor.h`._
