# DAI_PerfMngr / AI_PerfMngrWorldSubsystem

_Declared in `Source/DAI_PerfMngr/Public/DAI_PerfMngrWorldSubsystem.h`._
