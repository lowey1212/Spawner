# DAI_PerfMngr — Documentation

_Newbie-friendly reference for Blueprint nodes and settings._

## Quick Start

- Look for nodes under the Blueprint category shown below.

- All node names start with `DAI_` to be easy to search.

- [(Global)]((Global).md)
- [Actor](Actor.md)
- [ActorComponent](ActorComponent.md)
- [AI_PerfMngrWorldSubsystem](AI_PerfMngrWorldSubsystem.md)
- [AI_ProxyHISMManager](AI_ProxyHISMManager.md)
- [m](m.md)
- [r](r.md)
- [UPerformanceComponentManager](UPerformanceComponentManager.md)
- [USignificanceManagerLibrary](USignificanceManagerLibrary.md)
- [y](y.md)