# DAI_PerfMngr / AI_ProxyHISMManager

_Declared in `Source/DAI_PerfMngr/Public/DAI_ProxyHISMManager.h`._

## Blueprint Nodes

### DAI_PrintAllHISMDebugInfo

> What this does: unknown.

- **Blueprint Category:** `DAI|Perf`

- **Node Type:** `BlueprintCallable`

**Signature**

`void Unknown()`

**Inputs**

_No inputs._

**Returns**: `void`


## Exposed Settings

| Setting | Type | Where | Notes |
|---|---|---|---|
| **DAI_down** (`int32`) | `` | `DAI|Perf` | BlueprintReadWrite |


### Setting Details

#### DAI_down (`int32`)

> How many instances to add to each HISM per tick by default (prevents hitching when spawning many

- **Type:** ``

- **Category (Details panel):** `DAI|Perf`

- **Specifiers:** BlueprintReadWrite

