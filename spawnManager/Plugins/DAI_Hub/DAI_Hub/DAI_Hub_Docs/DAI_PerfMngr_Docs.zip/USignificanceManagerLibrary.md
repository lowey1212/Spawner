# DAI_PerfMngr / USignificanceManagerLibrary

_Declared in `Source/DAI_PerfMngr/Public/SignificanceManagerLibrary.h`._

## Blueprint Nodes

### DAI_RegisterActorWithSignificance

> What this does: unknown.

- **Blueprint Category:** `DAI|Perf`

- **Node Type:** `BlueprintCallable`

**Signature**

`void Unknown()`

**Inputs**

_No inputs._

**Returns**: `void`
