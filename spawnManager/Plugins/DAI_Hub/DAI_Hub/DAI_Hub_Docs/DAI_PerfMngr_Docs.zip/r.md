# DAI_PerfMngr / r

_Declared in `Source/DAI_PerfMngr/Public/ProxyHISMRootActor.h`._
